package csfall2018.recipeonthecloud;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.Buffer;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;


public class fetchdata extends AsyncTask<Void,Void,Void> {
    //String data = "";
    StringBuilder data = new StringBuilder();
    String type;
    String title;
    StringBuilder label = new StringBuilder();
    StringBuilder url = new StringBuilder();


    @Override
    protected Void doInBackground(Void... voids) {

        try {
            //  URL url = new URL("https://api.edamam.com/search?q=chinese&app_id=1e0ebb00&app_key=f2a8e80ab83d45e082a4b46f9d94d8dc&to=2&calories=300&time=20");
            URL url = new URL("https://api.myjson.com/bins/rp66i");
            HttpsURLConnection httpURLConnection = (HttpsURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line =  " ";

            while (line != null){
                line = bufferedReader.readLine();
                data .append(line).append("\n");
            }

            JSONObject jsonObject = new JSONObject(data.toString());
            type = jsonObject.getString("q");


            JSONArray arr = jsonObject.getJSONArray("hits");
            label.append(arr.getJSONObject(0).getJSONObject("recipe").getString("label"));
            label.append(arr.getJSONObject(0).getJSONObject("recipe").getString("url"));
            label.append(arr.getJSONObject(0).getJSONObject("recipe").getString("image"));
            System.out.println("hhhhhhhhhhhhhhhhh " + label);


        }catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }catch (JSONException e){
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

    }
}
