package csfall2018.recipeonthecloud;

public class dataCenter {

    public static  String KEY_ingredient = "1";
    public static  String KEY_diet = "2";
    public static  String KEY_allerigc= "3";
}
