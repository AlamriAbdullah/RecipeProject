package csfall2018.recipeonthecloud;


import java.net.URL;

public class Recipes {
    public String type;
    public String label;
    public String image;
    public String link;
    public String source;
    public String ingredients;

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public Recipes(){
        super();
    }

    public Recipes( String label, String image, String link, String source, String ingredients) {
        this.setLabel(label);
        this.setImage(image);
        this.setLink(link);
        this.setSource(source);
        this.setIngredients(ingredients);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String diet) {
        this.label = diet;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Override
    public String toString() {
        return "Recipes{" +
                "type='" + type + '\'' +
                ", label='" + label + '\'' +
                ", image='" + image + '\'' +
                ", link='" + link + '\'' +
                ", source='" + source + '\'' +
                '}';
    }


}
