package csfall2018.recipeonthecloud;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class RecipeAdapter extends ArrayAdapter {
    List list = new ArrayList();

    public RecipeAdapter(Context context, int resource) {
        super(context, resource);
    }


    public void add(Recipes object) {
        super.add(object);
        list.add(object);
    }

    @Override
    public int getCount() {
        return list.size();
    }


    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public View getView(int position, View convertView,  ViewGroup parent) {
        View row;
        row = convertView;

        RecipesHolder recipesHolder;


        if (row == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            row = layoutInflater.inflate(R.layout.row_layout,parent,false);
            recipesHolder = new RecipesHolder();
            recipesHolder.tx_label = row.findViewById(R.id.tx_label);
            recipesHolder.tx_source= row.findViewById(R.id.tx_source);
            recipesHolder.imageView = row.findViewById(R.id.imageView);
            row.setTag(recipesHolder);
        }else {
            recipesHolder = (RecipesHolder) row.getTag();
        }

        Recipes recipes = (Recipes) this.getItem(position);
        recipesHolder.tx_label.setText(recipes.label);
        recipesHolder.tx_source.setText(recipes.source);


       // ImageView imageView = convertView.findViewById(R.id.imageView);
       Picasso.get().load(recipes.image).into(recipesHolder.imageView);



        return row;
    }

    static class RecipesHolder {
        TextView tx_label,tx_source;
        ImageView imageView;;

    }
}
