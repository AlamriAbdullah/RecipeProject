package csfall2018.recipeonthecloud;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

     String json_string ;

     String mainIngredient;
     String diet;
     String allergies;


    Button create;
    RadioGroup gr1;
    RadioGroup gr2;
    RadioButton dietButton;
    RadioButton allergisButton;

    private EditText ingredientEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        create = findViewById(R.id.buttonCreate);
//
//        gr1 = findViewById(R.id.radioGroup1);
//        int dietID = gr1.getCheckedRadioButtonId();
//        dietButton = findViewById(dietID);
//
//        gr2 = findViewById(R.id.radioGroup2);
//        int AllergicID = gr2.getCheckedRadioButtonId();
//        allergisButton = findViewById(AllergicID);
//
//        ingredientEditText = findViewById(R.id.ingredientInput);


    }




   class BackgroundTask extends AsyncTask<Void,Void,Void>{
       //String data = "";
       StringBuilder data = new StringBuilder();
       String type;
       String title;
       StringBuilder label = new StringBuilder();

       String url1 = "https://api.edamam.com/search?q=+"+mainIngredient+"&app_id=1e0ebb00&app_key=f2a8e80ab83d45e082a4b46f9d94d8dc&to=11&diet="+diet+"&health="+allergies;
       protected Void doInBackground(Void... voids) {


           try {
                 //URL url = new URL("https://api.edamam.com/search?q=chinese&app_id=1e0ebb00&app_key=f2a8e80ab83d45e082a4b46f9d94d8dc&to=10&diet=balanced&health=alcohol-free");
               URL url = new URL(url1);
               HttpsURLConnection httpURLConnection = (HttpsURLConnection) url.openConnection();
               InputStream inputStream = httpURLConnection.getInputStream();
               BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
               String line =  " ";

               while (line != null){
                   line = bufferedReader.readLine();
                   data.append(line).append("\n");
                   //json_string += line + "\n";
               }


           }catch (MalformedURLException e){
               e.printStackTrace();
           }catch (IOException e){
               e.printStackTrace();
           }

           return null;
       }

       @Override
       protected void onPostExecute(Void aVoid) {
           super.onPostExecute(aVoid);
           json_string = data.toString();
       }

   }

   public void rblick(View view) {

                gr1 = findViewById(R.id.radioGroup1);
                gr2 = findViewById(R.id.radioGroup2);

                ingredientEditText = findViewById(R.id.ingredientInput);

                // get selected radio button from radioGroup
                int dietID = gr1.getCheckedRadioButtonId();
                int AllergicID = gr2.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                dietButton = findViewById(dietID);
                allergisButton = findViewById(AllergicID);

                ingredientEditText = findViewById(R.id.ingredientInput);

                mainIngredient = ingredientEditText.getText().toString();
                 diet = dietButton.getText().toString();
                allergies = allergisButton.getText().toString();

                mainIngredient = mainIngredient.toLowerCase();
                diet = diet.toLowerCase();
                allergies = allergies.toLowerCase();




        BackgroundTask process = new BackgroundTask();
        process.execute();

       if (json_string == null) {
           Toast.makeText(getApplicationContext(), "First get Json: " + mainIngredient, Toast.LENGTH_LONG).show();
       }else {
           Toast.makeText(getApplicationContext(), "Passed", Toast.LENGTH_LONG).show();
           Intent intent = new Intent(this,DisplayListView.class);
           intent.putExtra("json_data",json_string);
           startActivity(intent);
       }
   }
}