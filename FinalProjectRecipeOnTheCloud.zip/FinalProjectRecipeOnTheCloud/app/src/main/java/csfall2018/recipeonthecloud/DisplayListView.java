package csfall2018.recipeonthecloud;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;

public class DisplayListView extends AppCompatActivity {
    String json_string;

    JSONObject jsonObject;
    JSONArray jsonArray;

    String type;
    String label;
    String urlLink;
    String urlImage;
    String source;
    String ingredients;

    RecipeAdapter recipeAdapter;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_listiew_layout);

        listView = findViewById(R.id.listview);

        recipeAdapter = new RecipeAdapter(this, R.layout.row_layout);
        listView.setAdapter(recipeAdapter);
        json_string = getIntent().getExtras().getString("json_data");

        try {
            jsonObject = new JSONObject(json_string);

            type = jsonObject.getString("q");
            JSONArray arr = jsonObject.getJSONArray("hits");

            JSONArray array;
            String result = "";


            for (int i = 0 ; i < arr.length(); i++) {
                label = (arr.getJSONObject(i).getJSONObject("recipe").getString("label"));
                urlLink = (arr.getJSONObject(i).getJSONObject("recipe").getString("url"));
                urlImage = (arr.getJSONObject(i).getJSONObject("recipe").getString("image"));
                source = (arr.getJSONObject(i).getJSONObject("recipe").getString("url"));



                Recipes recipes = new Recipes(label,urlImage,urlLink,source,result);

                recipeAdapter.add(recipes);

            }



        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}

// for (int i = 0 ; i < arr.length(); i++) {
//        label = (arr.getJSONObject(i).getJSONObject("recipe").getString("label"));
//        urlLink = (arr.getJSONObject(i).getJSONObject("recipe").getString("url"));
//        urlImage = (arr.getJSONObject(i).getJSONObject("recipe").getString("image"));
//        source = (arr.getJSONObject(i).getJSONObject("recipe").getString("source"));
//
//        Recipes recipes = new Recipes(label,urlLink,urlImage,source);
//
//        }