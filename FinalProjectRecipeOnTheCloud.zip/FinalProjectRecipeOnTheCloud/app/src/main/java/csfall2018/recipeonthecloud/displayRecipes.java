package csfall2018.recipeonthecloud;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class displayRecipes extends AppCompatActivity  {
    private static final String TAG = displayRecipes.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_display_recipes);
        TextView textView = findViewById(R.id.textView);


        StringBuilder msg = new StringBuilder("Welcome \n");

        Intent intent = getIntent();
        Bundle b = intent.getExtras();

        if (b.containsKey(dataCenter.KEY_ingredient)) {
            String name = b.getString(dataCenter.KEY_ingredient, "mydefult");
            msg.append("\n").append(name);
            Log.i(TAG, "Name : " + name);
        }

        if (b.containsKey(dataCenter.KEY_diet)) {
            String age = b.getString(dataCenter.KEY_diet, "demo");
            msg.append("\n").append(age);
         //  Log.i(TAG, "Age : " + age);
        }

        if (b.containsKey(dataCenter.KEY_allerigc)) {
            String allergic = b.getString(dataCenter.KEY_allerigc, "demo");
            msg.append("\n").append(allergic);
            Log.i(TAG,allergic );
        }



        //textView.setText(msg);
    }




    }


